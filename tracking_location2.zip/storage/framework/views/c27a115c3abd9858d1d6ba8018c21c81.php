<!-- resources/views/emails/tracking_request.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tracking Request</title>
</head>
<body>
    <h1>Tracking Request</h1>
    <p>You are requested to share your location. Click below:</p>
    <a href="<?php echo e(route('approve.tracking.request', $token)); ?>" class="btn">Share Location</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/emails/tracking_request.blade.php ENDPATH**/ ?>