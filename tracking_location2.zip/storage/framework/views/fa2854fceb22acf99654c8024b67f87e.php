<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>