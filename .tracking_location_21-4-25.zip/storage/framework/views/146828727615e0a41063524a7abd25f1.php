<!DOCTYPE html>
<html>
<head>
    <title>Share Location</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

<h2>Allow Location Access</h2>

<button onclick="getLocation()">Share My Location</button>

<script>
    // CSRF Token from meta tag
    const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Location function
    function getLocation() {
        navigator.geolocation.getCurrentPosition(function (position) {
            fetch("<?php echo e(route('tracking.save-location')); ?>", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": csrf
                },
                body: JSON.stringify({
                    token: "<?php echo e($trackingRequest->token); ?>",
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                })
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message || "Location shared!");
                window.close(); // optional
            });
        }, function (error) {
            alert("Location access denied.");
        });
    }

    // Auto-call location when page loads
    window.onload = function () {
        getLocation();
    }
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/dashboard/pages/get_location.blade.php ENDPATH**/ ?>