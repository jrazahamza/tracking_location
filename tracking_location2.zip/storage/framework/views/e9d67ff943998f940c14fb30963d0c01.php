
<!-- resources/views/tracking/send_request.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Tracking Request</title>
</head>
<body>
    <h1>Send Tracking Request</h1>

    <?php if(session('message')): ?>
        <p><?php echo e(session('message')); ?></p>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('tracking.send')); ?>">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Enter email to track" required>
        <button type="submit">Send Request</button>
    </form>
    <?php if(session('message')): ?> <p><?php echo e(session('message')); ?></p> <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/tracking/send_request.blade.php ENDPATH**/ ?>