<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrackingRequest extends Model
{
    protected $fillable = [
        'target_user_email', 'user_id', 'token', 'latitude', 'longitude'
    ];
}
