<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Tracking: <?php echo e($email); ?></h3>
        <div id="map" style="width: 100%; height: 500px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function initMap() {
            const location = {
                lat: <?php echo e($latitude); ?>,
                lng: <?php echo e($longitude); ?>

            };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: location,
            });
            new google.maps.Marker({
                position: location,
                map: map
            });
        }
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCuntvsKMaVBt5UEMOzbh5BmY5KnOBAozw&callback=initMap"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/dashboard/pages/track.blade.php ENDPATH**/ ?>