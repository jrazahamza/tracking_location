<?php

namespace App\Http\Controllers;

use App\Mail\TrackingRequestEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Models\TrackingRequest;

class TrackingController extends Controller
{
    public function showTrackingForm() {
        return view('dashboard.pages.send_request');
    }

    public function sendTrackingRequest(Request $request) {
        $request->validate(['email' => 'required|email']);
        $token = Str::random(60);

        TrackingRequest::create([
            'user_id' => Auth::id(),
            'target_user_email' => $request->email,
            'token' => $token,
        ]);

        Mail::to($request->email)->send(new TrackingRequestEmail($token));
        return back()->with('message', 'Tracking request sent successfully!');
    }

    public function approveTrackingRequest($token) {
        $trackingRequest = TrackingRequest::where('token', $token)->firstOrFail();
        return view('dashboard.pages.get_location', compact('trackingRequest'));
    }

    public function saveLocation(Request $request) {
        $request->validate([
            'token' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
        ]);

        $trackingRequest = TrackingRequest::where('token', $request->token)->firstOrFail();
        if (!$trackingRequest) {
            return response()->json(['message' => 'Invalid tracking token.'], 404);
        }
        $trackingRequest->update([
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'is_approved' => true,
        ]);

        return response()->json(['message' => 'Location saved successfully.']);
    }

    public function trackUser($id) {
        $tracking = TrackingRequest::findOrFail($id);
        return view('dashboard.pages.track', [
            'latitude' => $tracking->latitude,
            'longitude' => $tracking->longitude,
            'email' => $tracking->target_user_email,
        ]);
    }

}
