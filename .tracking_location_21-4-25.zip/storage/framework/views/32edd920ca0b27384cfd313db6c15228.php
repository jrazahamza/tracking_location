<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Send Tracking Request</h1>

<?php if(session('message')): ?>
    <p><?php echo e(session('message')); ?></p>
<?php endif; ?>
<?php if(session('error')): ?>
    <p style="color: red;"><?php echo e(session('error')); ?></p>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('tracking.send')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email"
               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter email to track"  required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger small"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button type="submit" class="btn btn-primary">Send Request</button>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/dashboard/pages/send_request.blade.php ENDPATH**/ ?>