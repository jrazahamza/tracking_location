<?php $__env->startSection('content'); ?>
    <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Tracking History</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Tracking History</li>
                        </ol>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">Tracking History</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Requester Name</th>
                                            <th>Target Email</th>
                                            <th>Latitude</th>
                                            <th>Longitude</th>
                                            <th>Created By</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $trackingRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="align-middle">
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($value->user ? $value->user->full_name : ''); ?></td>
                                                <td><?php echo e($value->target_user_email); ?></td>
                                                <td><?php echo e($value->latitude); ?></td>
                                                <td><?php echo e($value->longitude); ?></td>
                                                <td><?php echo e($value->created_at->format('d-M-Y')); ?></td>

                                                <td>
                                                    
                                                    <a href="<?php echo e(route('tracking.view', $value->id)); ?>"
                                                        class="btn btn-primary">
                                                        <i class="fas fa-map-marker-alt"></i> Track
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end mt-4">
                                    <?php echo e($trackingRequests->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                            <!-- /.card-body -->
                            
                        </div>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::App Content-->
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Muhammad_Anus\tracking_location2\resources\views/dashboard/pages/tracking_history.blade.php ENDPATH**/ ?>